<?php
class M_post extends CI_Model{
	
	function get_post(){
		$hsl = $this->db->get('prci_post');
		return $hsl;
	}

    function get_posttype_by_id($id) {
        $hsl = $this->db->get_where('prci_posttype', ['id' => $id])->row_array();
        return $hsl;
    }

    function update_kategori_post($id,$kategori_name) { 
		$data = [
			"kategori_name" => $kategori_name,
		];
		$this->db->where('id_post', $id);
		$this->db->update('prci_post', $data);
    }

    function update_posttype_post($id,$kategori_name) { 
		$data = [
			"post_type_name" => $kategori_name,
		];
		$this->db->where('id_post', $id);
		$this->db->update('prci_post', $data);
    }

    function get_tipe_by_id($id) { 
		$hsl = $this->db->get_where('prci_posttype', ['id' => $id])->row_array();
		return $hsl;
    }

    function get_tipe_by_slug($id) { 
		$hsl = $this->db->get_where('prci_posttype', ['slug' => $id])->row_array();
		return $hsl;
    }

    function update_tipe($id,$tipename,$tipeslug) { 
		$data = [
			"name" => $tipename,
			"slug" => $tipeslug,
			"updated_at" => date("Y-m-d h:i:s"),
		];
		$this->db->where('id', $id);
		$this->db->update('prci_posttype', $data);
    }

    function insert_tipe($tipename,$tipeslug) { 
		$data = [
			"name" => $tipename,
			"slug" => $tipeslug,
			"created_at" => date("Y-m-d h:i:s"),
			"updated_at" => date("Y-m-d h:i:s"),
		];
		$this->db->insert('prci_posttype', $data);
    }

	function hapus_tipe($id) {
		$hsl = $this->db->delete('prci_posttype', array('id' => $id));
		return $hsl;
	}

	public function get_post_from_idpostype($id) {
		$hsl = $this->db->get_where('prci_post', ['post_type' => $id]);
		return $hsl;
	}

	public function get_type_post_obj() {
		$hsl = $this->db->get('prci_posttype');
		return $hsl;
	}

	public function get_type_post(){
		$this->db->order_by('id', 'ASC');
		$hsl = $this->db->get('prci_posttype');
		$no = 0;
		foreach ($hsl->result() as $row){
			$jml_post = 0;
			$hasil = $this->get_post_from_idpostype($row->id);
			$hasils[$no]['id'] = $row->id;
			$hasils[$no]['name'] = $row->name;
			$hasils[$no]['slug'] = $row->slug;
			$hasils[$no]['created_at'] = $row->created_at;
			foreach($hasil->result() as $rw){
				$hasils[$no]['post'][$jml_post]['id'] = $rw->id_post;
				$hasils[$no]['post'][$jml_post]['judul'] = $rw->judul;
				$hasils[$no]['post'][$jml_post]['slug'] = $rw->slug;
				$hasils[$no]['post'][$jml_post]['kategori'] = $rw->kategori;
				$hasils[$no]['post'][$jml_post]['date_created'] = $rw->date_created;
				// $hasils[$no]['post']['deskripsi'] = $rw->deskripsi;
				$jml_post++;
			}
			$hasils[$no]['jml_post'] = $jml_post;
			$no++;
		}
		return $hasils;
	}
	
	public function search($id) {
		$query = "SELECT * FROM `prci_post` WHERE `deskripsi` LIKE '%".$id."%'";
		$hsl = $this->db->query($query);
		return $hsl;
		// return $query;
	}

	public function get_kategori($id) {
		$hsl = $this->db->get_where('prci_post', ['kategori' => $id]);
		return $hsl;
	}

	public function get_posttipe_by_slug($id) {
		$hsl = $this->db->get_where('prci_posttype', ['slug' => $id])->row_array();
		return $hsl;
	}

	function get_post_list($limit, $start){
		$this->db->order_by('id_post', 'DESC');
        $query = $this->db->get_where('prci_post', ['post_type' => 1], $limit, $start);
        return $query;
    }

	function get_postipe_post_list($id, $limit, $start){
		$this->db->order_by('id_post', 'DESC');
        $query = $this->db->get_where('prci_post', ['post_type' => $id], $limit, $start);
        return $query;
    }

	public function get_posttipe($id) {
		$hsl = $this->db->get_where('prci_post', ['post_type' => $id]);
		return $hsl;
	}

}