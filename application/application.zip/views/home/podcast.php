<main id="main" class="main-page">
    <section id="ttgAplikasi" class="wow fadeInUp mt-3 p-3">
      <div class="container mt-3">
        <div class="row">
            <!-- col -->
            <div class="col">
            
                <div class="h1">
                <h1>PRC Podcast</h1>
                <hr style="border:5px solid orange;margin-bottom: 30px">
                </div>

                <div class="row">
                <?php  
                foreach ($data->result() as $row) { 
                ?>
                    <div class="col-md-3 col-sm-6">
                    <img src="<?= base_url() ?>assets/images/<?= $row->featured_image ?>" class="img-fluid mb-2">
                    <b><a href="<?= base_url() ?>podcast/<?= $row->slug ?>"><p style="line-height: 1.3;color:#ff4a1a"><?= $row->judul ?></p></a></b>
                    <p style="color: gray;margin-top: -16px;font-size:14px"><i class="fas fa-user mt-2 mb-2"> </i> Admin, <span class="far fa-calendar-alt"></span> <?= $row->date_created ?></p>
                    <div style="margin-top: -16px;font-size: 16px;line-height: 1.3;">
                        <p><?=  limit_words($row->deskripsi, 20); ?></p>
                    </div>
                    </div>
                <?php 
                }
                ?>
                </div>
                    <div class="float-right"><?php echo $pagination; ?></div>
            </div>
            </div>
            <!-- // col -->
        </div>
        <!-- // row -->
  	</section>
</main>
