  <main id="main" class="main-page  ">

    <!--==========================
      Speaker Details Section
    ============================-->
    <section id="speakers-details" class="wow fadeIn">
      <div class="container">
        <div class="text-center">
          <h2 class=" text-uppercase" style="font-size: 26px"><b>Data Sebaran Virus Corona di Kabupaten <?= $kabupaten ?></b></h2>
          <h5 style="color: gray;opacity: 80%"><b>Poverty Resource Center Initiative</b></h5>
          <hr width="20%" style="color:red;border:3px solid red;margin-top: -2px">
        </div>
        <br>
        <div class="row">
          <div class="col">
            <div class="flourish-embed flourish-map" data-src="visualisation/1732709"><script src="https://public.flourish.studio/resources/embed.js"></script></div>
          </div>
        </div>

      </div>
    </section>

  </main>
<!-- <?php var_dump($genders) ?> -->